import { Search, Bell, Home, Play, Plus, Server, Wallet, Zap, Sun, Moon } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { useState } from 'react';

export default function App() {
  const [isDark, setIsDark] = useState(true);
  const profiles = [
    {
      name: "Beauty",
      image: "https://images.unsplash.com/photo-1557053910-d9eadeed1c58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc1OTkyNzgwN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      name: "EMEN",
      image: "https://images.unsplash.com/photo-1683998215234-02fca98a3b54?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdCUyMHBlcnNvbiUyMGZhY2V8ZW58MXx8fHwxNzU5OTI3ODA0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      name: "Rockwel",
      image: "https://images.unsplash.com/photo-1722322426803-101270837197?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW4lMjBwcm9maWxlJTIwcGhvdG98ZW58MXx8fHwxNzU5OTI3ODEwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      name: "Animal",
      image: "https://images.unsplash.com/photo-1683998215234-02fca98a3b54?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdCUyMHBlcnNvbiUyMGZhY2V8ZW58MXx8fHwxNzU5OTI3ODA0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  const videos = [
    {
      title: "Adele - Easy On Me (Live at the NRJ Awards 2021)",
      creator: "Adele",
      views: "5.8M views",
      time: "3 months ago",
      thumbnail: "https://images.unsplash.com/photo-1759503407457-3683579f080b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHNwZWFraW5nJTIwbWljcm9waG9uZXxlbnwxfHx8fDE3NTk4OTcyMzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      duration: "3:47",
      isLive: true
    },
    {
      title: "Lord of Rings: The Rings of Power Official Trailer",
      creator: "Prime Video",
      views: "12M views",
      time: "1 week ago", 
      thumbnail: "https://images.unsplash.com/photo-1576497587501-f71f94bef499?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwbWVkaWV2YWwlMjBjaGFyYWN0ZXJ8ZW58MXx8fHwxNzU5OTI3ODE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      duration: "2:30"
    }
  ];

  const shorts = [
    {
      title: "Amazing Dance Moves",
      creator: "DanceQueen",
      views: "2.3M",
      thumbnail: "https://images.unsplash.com/photo-1560088186-8811763e95d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXJ0aWNhbCUyMHZpZGVvJTIwcG9ydHJhaXQlMjBkYW5jaW5nfGVufDF8fHx8MTc1OTkyODU2NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "Quick Recipe Tips",
      creator: "FoodieLife",
      views: "1.8M",
      thumbnail: "https://images.unsplash.com/photo-1718324864477-0a7811b309b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwcmVjaXBlJTIwc2hvcnQlMjB2aWRlb3xlbnwxfHx8fDE3NTk5Mjg1NjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "Workout Challenge",
      creator: "FitGuru",
      views: "3.1M",
      thumbnail: "https://images.unsplash.com/photo-1718975102800-fb102d865db5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwd29ya291dCUyMHZlcnRpY2FsfGVufDF8fHx8MTc1OTkyODU2Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "Gaming Setup Tour",
      creator: "GameZone",
      views: "950K",
      thumbnail: "https://images.unsplash.com/photo-1756575802484-7aab6829d600?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMHZlcnRpY2FsfGVufDF8fHx8MTc1OTkyODU2Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  const bgColor = isDark ? '#041105' : '#F1FCF2';
  const textColor = isDark ? 'text-white' : 'text-gray-900';
  const secondaryTextColor = isDark ? 'text-gray-300' : 'text-gray-600';
  const mutedTextColor = isDark ? 'text-gray-400' : 'text-gray-500';
  const iconColor = isDark ? 'text-white' : 'text-gray-900';
  const cardBg = isDark ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)';
  const borderColor = isDark ? 'border-gray-700' : 'border-gray-300';

  return (
    <div className={`min-h-screen ${textColor} max-w-md mx-auto`} style={{ backgroundColor: bgColor }}>
      {/* Header */}
      <div className="flex items-center justify-between p-4" style={{ backgroundColor: bgColor }}>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#50A040] rounded flex items-center justify-center">
            <Play className="w-4 h-4 text-white fill-white" />
          </div>
          <span className={textColor + " text-xl"} style={{ fontFamily: 'Fredoka One, cursive' }}>twikkl</span>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => setIsDark(!isDark)} className={iconColor}>
            {isDark ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
          </button>
          <Search className={`w-6 h-6 ${iconColor}`} />
          <Bell className={`w-6 h-6 ${iconColor}`} />
          <div className="w-8 h-8 rounded-full overflow-hidden">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1683998215234-02fca98a3b54?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdCUyMHBlcnNvbiUyMGZhY2V8ZW58MXx8fHwxNzU5OTI3ODA0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Profile"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="px-4 py-2">
        <div className="flex gap-3 text-sm">
          <span className={isDark ? "bg-white text-black px-3 py-1 rounded-full" : "bg-gray-900 text-white px-3 py-1 rounded-full"}>All</span>
          <span className={secondaryTextColor}>Gaming</span>
          <span className={secondaryTextColor}>Figma</span>
          <span className={secondaryTextColor}>UI Design</span>
          <span className={secondaryTextColor}>UI design</span>
        </div>
      </div>

      {/* Story-like profiles */}
      <div className="px-4 py-3">
        <div className="flex gap-4">
          {profiles.map((profile, index) => (
            <div key={index} className="flex flex-col items-center gap-1">
              <div className={`w-14 h-14 rounded-full border-2 ${isDark ? 'border-gray-600' : 'border-gray-400'} p-0.5`}>
                <div className="w-full h-full rounded-full overflow-hidden">
                  <ImageWithFallback
                    src={profile.image}
                    alt={profile.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <span className={`text-xs ${secondaryTextColor} text-center`}>{profile.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Shorts Section */}
      <div className="px-4 py-3">
        <h2 className={`${textColor} text-lg mb-3`} style={{ fontFamily: 'Fredoka One, cursive' }}>Shorts</h2>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide">
          {shorts.map((short, index) => (
            <div key={index} className="flex-shrink-0 w-28">
              <div className="relative aspect-[9/16] rounded-lg overflow-hidden">
                <ImageWithFallback
                  src={short.thumbnail}
                  alt={short.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white px-1 py-0.5 text-xs rounded flex items-center gap-1">
                  <Zap className="w-3 h-3" />
                </div>
              </div>
              <div className="mt-2">
                <h3 className={`${textColor} text-xs leading-tight mb-1 line-clamp-2`}>
                  {short.title}
                </h3>
                <div className={`${mutedTextColor} text-xs`}>
                  {short.views} views
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Video Content */}
      <div className="space-y-4">
        {videos.map((video, index) => (
          <div key={index} className="rounded-lg overflow-hidden mx-4" style={{ backgroundColor: cardBg }}>
            <div className="relative">
              <ImageWithFallback
                src={video.thumbnail}
                alt={video.title}
                className="w-full h-48 object-cover"
              />
              {video.isLive && (
                <div className="absolute top-2 left-2 bg-[#50A040] text-white px-2 py-1 text-xs rounded">
                  Live
                </div>
              )}
              <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white px-1 py-0.5 text-xs rounded">
                {video.duration}
              </div>
            </div>
            <div className="p-3">
              <div className="flex gap-3">
                <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0">
                  <ImageWithFallback
                    src={profiles[0].image}
                    alt={video.creator}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className={`${textColor} text-sm leading-tight mb-1 line-clamp-2`}>
                    {video.title}
                  </h3>
                  <div className={`${mutedTextColor} text-xs`}>
                    <div className="flex items-center gap-1">
                      <span>{video.creator}</span>
                    </div>
                    <div>{video.views} • {video.time}</div>
                  </div>
                </div>
                <div className="flex-shrink-0">
                  <div className="w-5 h-5 flex flex-col justify-center items-center">
                    <div className={`w-1 h-1 ${mutedTextColor === 'text-gray-400' ? 'bg-gray-400' : 'bg-gray-500'} rounded-full mb-0.5`}></div>
                    <div className={`w-1 h-1 ${mutedTextColor === 'text-gray-400' ? 'bg-gray-400' : 'bg-gray-500'} rounded-full mb-0.5`}></div>
                    <div className={`w-1 h-1 ${mutedTextColor === 'text-gray-400' ? 'bg-gray-400' : 'bg-gray-500'} rounded-full`}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Button */}
      <div className="fixed bottom-20 right-4">
        <button className="w-14 h-14 bg-[#50A040] rounded-full flex items-center justify-center shadow-lg">
          <Plus className="w-6 h-6 text-white" />
        </button>
      </div>

      {/* Bottom Navigation */}
      <div className={`fixed bottom-0 left-0 right-0 max-w-md mx-auto border-t ${borderColor}`} style={{ backgroundColor: bgColor }}>
        <div className="flex justify-around py-2">
          <div className="flex flex-col items-center py-2">
            <Home className={`w-6 h-6 ${iconColor}`} />
            <span className={`text-xs ${textColor} mt-1`}>Home</span>
          </div>
          <div className="flex flex-col items-center py-2">
            <Zap className={`w-6 h-6 ${mutedTextColor}`} />
            <span className={`text-xs ${mutedTextColor} mt-1`}>Shorts</span>
          </div>
          <div className="flex flex-col items-center py-2">
            <Server className={`w-6 h-6 ${mutedTextColor}`} />
            <span className={`text-xs ${mutedTextColor} mt-1`}>Servers</span>
          </div>
          <div className="flex flex-col items-center py-2">
            <Wallet className={`w-6 h-6 ${mutedTextColor}`} />
            <span className={`text-xs ${mutedTextColor} mt-1`}>Wallet</span>
          </div>
        </div>
      </div>
      
      {/* Bottom spacing for fixed navigation */}
      <div className="h-20"></div>
    </div>
  );
}