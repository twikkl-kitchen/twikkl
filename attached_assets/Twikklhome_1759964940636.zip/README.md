
  # Twikkl

  This is a code bundle for Twikkl. The original project is available at https://www.figma.com/design/hbxZlTXuJYN9kiSzVY2R0p/Twikkl.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  