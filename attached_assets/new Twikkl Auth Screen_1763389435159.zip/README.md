
  # Update Twikkl Auth Screen

  This is a code bundle for Update Twikkl Auth Screen. The original project is available at https://www.figma.com/design/2F5s92q3JWsNWt7s6GAAYD/Update-Twikkl-Auth-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  